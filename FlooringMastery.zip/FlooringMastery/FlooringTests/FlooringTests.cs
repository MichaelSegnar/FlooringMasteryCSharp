﻿using NUnit.Framework;
using System;
using NodaTime;
using java.math;

namespace FlooringTests
{
	[TestFixture]
    public class FlooringTests
    {
		LocalDate testFile1 = new LocalDate(2040, 12, 12);//sample file for test cases
		LocalDate testFile2 = new LocalDate(2041, 12, 12);//sample file for test cases


		[SetUp]
		void clear()
		{
			FlooringMastery.DAO.orders.clearList();
		}

		[Test]
		void addTest()
		{
			int original = FlooringMastery.DAO.orders.numOrders();
			FlooringMastery.DAO.orders.addIt(FlooringMastery.DAO.orders.numOrders() + 1, "Dummy", "Michigan", new BigDecimal("4.45"), "Laminate", new BigDecimal("320.00"), new BigDecimal("1.75"), new BigDecimal("2.10"), new BigDecimal("560.00"), new BigDecimal("672.00"), new BigDecimal("54.82"), new BigDecimal("1286.82"));
			Assert.IsTrue(FlooringMastery.DAO.orders.numOrders() > original);
		}

		[Test]
		void deleteTest()
		{
			FlooringMastery.DAO.orders.addIt(FlooringMastery.DAO.orders.numOrders() + 1, "Dummy", "Michigan", new BigDecimal("4.45"), "Laminate", new BigDecimal("320.00"), new BigDecimal("1.75"), new BigDecimal("2.10"), new BigDecimal("560.00"), new BigDecimal("672.00"), new BigDecimal("54.82"), new BigDecimal("1286.82"));
			FlooringMastery.DAO.orders.addIt(FlooringMastery.DAO.orders.numOrders() + 1, "Dummy", "Michigan", new BigDecimal("4.45"), "Laminate", new BigDecimal("320.00"), new BigDecimal("1.75"), new BigDecimal("2.10"), new BigDecimal("560.00"), new BigDecimal("672.00"), new BigDecimal("54.82"), new BigDecimal("1286.82"));
			int original = FlooringMastery.DAO.orders.numOrders();
			FlooringMastery.DAO.orders.remove(1);
			Assert.IsTrue(FlooringMastery.DAO.orders.numOrders() < original);
		}

		[Test]
		void editTest()
		{
			FlooringMastery.Model.loadEx.download();
			FlooringMastery.DAO.orders.addIt(FlooringMastery.DAO.orders.numOrders() + 1, "Dummy", "Michigan", new BigDecimal("4.45"), "Laminate", new BigDecimal("320.00"), new BigDecimal("1.75"), new BigDecimal("2.10"), new BigDecimal("560.00"), new BigDecimal("672.00"), new BigDecimal("54.82"), new BigDecimal("1286.82"));

			String firstName = FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getCN();
			FlooringMastery.DAO.orders.newName(FlooringMastery.DAO.orders.numOrders(), "Faker");
			Assert.IsFalse(firstName.Equals(FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getCN()));

			String firstState = FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getS();
			BigDecimal firstTaxRate = FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getTR();
			BigDecimal firstTax = FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getTx();
			BigDecimal firstTotal = FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getTl();
			FlooringMastery.DAO.orders.newState(FlooringMastery.DAO.orders.numOrders(), "OH");
			Assert.IsFalse(firstState.Equals(FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getS()));
			Assert.IsFalse(firstTaxRate.compareTo(FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getTR()) == 0);
			Assert.IsFalse(firstTax.compareTo(FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getTx()) == 0);
			Assert.IsFalse(firstTotal.compareTo(FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getTl()) == 0);

			String firstProduct = FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getPT();
			firstTax = FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getTx();
			firstTotal = FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getTl();
			BigDecimal firstCPSF = FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getCPSF();
			BigDecimal firstLCPSF = FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getLCPSF();
			BigDecimal firstLC = FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getLC();
			BigDecimal firstMC = FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getMC();
			FlooringMastery.DAO.orders.newPro(FlooringMastery.DAO.orders.numOrders(), "Wood");
			Assert.IsFalse(firstProduct.Equals(FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getPT()));
			Assert.IsFalse(firstCPSF.compareTo(FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getCPSF()) == 0);
			Assert.IsFalse(firstLCPSF.compareTo(FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getLCPSF()) == 0);
			Assert.IsFalse(firstTax.compareTo(FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getTx()) == 0);
			Assert.IsFalse(firstTotal.compareTo(FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getTl()) == 0);
			Assert.IsFalse(firstLC.compareTo(FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getLC()) == 0);
			Assert.IsFalse(firstMC.compareTo(FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getMC()) == 0);

			BigDecimal firstArea = FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getA();
			firstLC = FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getLC();
			firstMC = FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getMC();
			firstTax = FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getTx();
			firstTotal = FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getTl();
			FlooringMastery.DAO.orders.newArea(FlooringMastery.DAO.orders.numOrders(), new BigDecimal("500.00"));//assume this is bigger
			Assert.IsTrue(firstCPSF.compareTo(FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getCPSF()) < 0);
			Assert.IsTrue(firstLC.compareTo(FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getLC()) < 0);
			Assert.IsTrue(firstMC.compareTo(FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getMC()) < 0);
			Assert.IsTrue(firstTax.compareTo(FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getTx()) < 0);
			Assert.IsTrue(firstTotal.compareTo(FlooringMastery.DAO.orders.orderList[FlooringMastery.DAO.orders.numOrders()].getTl()) < 0);
		}

		[Test]
		void displayTest()
		{
			FlooringMastery.Model.saveNload.load(testFile1);
			FlooringMastery.DAO.orders.addIt(FlooringMastery.DAO.orders.numOrders() + 1, "Dummy", "Michigan", new BigDecimal("4.45"), "Laminate", new BigDecimal("320.00"), new BigDecimal("1.75"), new BigDecimal("2.10"), new BigDecimal("560.00"), new BigDecimal("672.00"), new BigDecimal("54.82"), new BigDecimal("1286.82"));
			int orderCount = FlooringMastery.DAO.orders.numOrders();
			FlooringMastery.Model.saveNload.save();

			FlooringMastery.Model.saveNload.load(testFile1);
			Assert.IsFalse(orderCount == FlooringMastery.DAO.orders.numOrders());
			FlooringMastery.Model.saveNload.save();

			FlooringMastery.Model.saveNload.load(testFile1);
			Assert.IsTrue(orderCount == FlooringMastery.DAO.orders.numOrders());
			FlooringMastery.Model.saveNload.save();
		}
	}
}
