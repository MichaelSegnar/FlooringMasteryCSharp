﻿using java.math;
using NodaTime;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlooringMastery.UserIO
{
    class inputs
    {
        public static int getInt(int min, int max)
        {
			bool invalid;
			int value = 1;

			do
			{
				invalid = false;
				String input = Console.ReadLine();

				try
				{
					Int32.Parse(input);
				}
				catch(FormatException)
				{
					View.invalids.not(input, "Integer");
					invalid = true;
				}

				if (!invalid)
				{
					value = Int32.Parse(input);
					if (value < min || value > max)
					{
						View.invalids.rangeError(input);
						invalid = true;
					}
				}

			} while (invalid);

			return value;
		}

		public static LocalDate getLD(bool future)
        {
			bool validM;
			bool validD;
			bool validY;
			bool validLD;

			String month = "", day = "", year = "";
			var now = DateTime.Now;

			LocalDate date = new LocalDate(now.Year, now.Month, now.Day);

			do
			{
				validLD = true;

				View.request.insert("Order Month");
				do
				{
					validM = true;
					month = Console.ReadLine();

					try
					{
						Int32.Parse(month);
					}
					catch (FormatException)
					{
						View.invalids.not(month, "Month");
						validM = false;
						month = "10";
					}

					int mCheck = Int32.Parse(month);
					if (mCheck <= 0 || mCheck > 12)
					{
						View.invalids.rangeError(month);
						validM = false;
					}
				} while (!validM);
				if (Int32.Parse(month) < 10) { month = "0" + month; }

				View.request.insert("Order Day");
				do
				{
					validD = true;
					day = Console.ReadLine();

					try
					{
						Int32.Parse(day);
					}
					catch (FormatException)
					{
						View.invalids.not(day, "Day");
						validD = false;
						day = "10";
					}

					int dCheck = Int32.Parse(day);
					if (dCheck <= 0 || dCheck > 31)
					{
						View.invalids.rangeError(day);
						validD = false;
					}
				} while (!validD);
				if (Int32.Parse(day) < 10) { day = "0" + day; }

				View.request.insert("Order Year");
				do
				{
					validY = true;
					year = Console.ReadLine();

					try
					{
						Int32.Parse(year);
					}
					catch (FormatException)
					{
						View.invalids.not(year, "Year");
						validY = false;
						year = "1000";
					}

					int yCheck = Int32.Parse(year);
					if (yCheck <= 0)
					{
						View.invalids.rangeError(year);
						validY = false;
					}
				} while (!validY);
				if (Int32.Parse(year) < 1000 && Int32.Parse(year) >= 999) { year = "0" + year; }
				else if (Int32.Parse(year) < 100 && Int32.Parse(year) >= 99) { year = "00" + year; }
				else if (Int32.Parse(year) < 10) { year = "000" + year; }

				try
				{
					new LocalDate(Int32.Parse(year), Int32.Parse(month), Int32.Parse(day));
				}
				catch (ArgumentOutOfRangeException)
				{
					View.invalids.notDate(year + "-" + month + "-" + day);
					validLD = false;
				}

				if (validLD)
				{
					date = new LocalDate(Int32.Parse(year), Int32.Parse(month), Int32.Parse(day));

					if (future)
					{
						int coming = date.CompareTo(new LocalDate(now.Year, now.Month, now.Day));
						if (coming <= 0)
						{
							View.invalids.future(new LocalDate(now.Year, now.Month, now.Day));
							validLD = false;
						}
					}
				}

			} while (!validLD);

			return date;
		}

		public static String getString()
        {
			return Console.ReadLine();
        }

		public static BigDecimal getBD(BigDecimal min)
		{
			bool invalid;
			BigDecimal value = new BigDecimal("1.00");

			do
			{
				invalid = false;
				String input = Console.ReadLine();

				try
				{
					new BigDecimal(input);
				}
				catch (FormatException)
				{
					View.invalids.not(input, "Big Decimal");
					invalid = true;
				}

				if (!invalid)
				{
					value = new BigDecimal(input);
					if (value.compareTo(min) < 0)
					{
						View.invalids.rangeError(input);
						invalid = true;
					}
				}

			} while (invalid);

			return value.setScale(2, RoundingMode.HALF_UP);
		}

		public static bool YN()
		{
			do
			{
				String decide = Console.ReadLine();

				if (decide.Equals("yes")) { return true; }
				else if (decide.Equals("no")) { return false; }
				else { View.invalids.undecided(); }

			} while (true);
		}
	}
}
