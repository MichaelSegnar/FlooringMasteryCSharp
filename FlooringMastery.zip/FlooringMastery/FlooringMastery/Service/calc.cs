﻿using java.math;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlooringMastery.Service
{
    class calc
    {
		public static BigDecimal costCalc(BigDecimal area, BigDecimal cost)
		{
			BigDecimal newCost = area.multiply(cost);
			return newCost.setScale(2, RoundingMode.HALF_UP);
		}

		public static BigDecimal Tax(BigDecimal MC, BigDecimal LC, BigDecimal taxRate)
		{
			BigDecimal MLC = MC.add(LC);
			BigDecimal taxBonus = taxRate.divide(new BigDecimal("100"));
			BigDecimal cost = MLC.multiply(taxBonus);

			return cost.setScale(2, RoundingMode.HALF_UP);
		}

		public static BigDecimal Total(BigDecimal MC, BigDecimal LC, BigDecimal tax)
		{
			BigDecimal MLC = MC.add(LC);
			BigDecimal cost = MLC.add(tax);

			return cost.setScale(2, RoundingMode.HALF_UP);
		}
	}
}
