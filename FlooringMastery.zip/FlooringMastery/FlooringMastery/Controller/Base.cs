﻿using NodaTime;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlooringMastery.Controller
{
    class Base
    {
        static void Main(string[] args)
        {
            Model.loadEx.download();

            bool running = true;

            do
            {
                View.request.menu();
                int select = UserIO.inputs.getInt(1,5);

                switch(select)
                {
                    case 1:
                        //display method
                        LocalDate orderDate = UserIO.inputs.getLD(false);
                        Model.saveNload.load(orderDate);
                        DAO.orders.display(orderDate);
                        break;
                    case 2:
                        modify.add();
                        break;
                    case 3:
                        modify.edit();
                        break;
                    case 4:
                        modify.remove();
                        break;
                    case 5:
                        running = false;
                        break;
                }
                if (select != 5) { Model.saveNload.save(); }
            } while (running);
        }
    }
}
