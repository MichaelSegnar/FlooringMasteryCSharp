﻿using java.math;
using NodaTime;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlooringMastery.Controller
{
    class modify
    {
        public static void add()
        {
			LocalDate orderDate = UserIO.inputs.getLD(true);
			Model.saveNload.load(orderDate);

			int orderNum = DAO.orders.numOrders() + 1;

			View.request.insert("Customer Name");
			String cusName = UserIO.inputs.getString();

			View.request.insert("State Name (Use abbreviation)");
			String state;
			do
			{
				state = UserIO.inputs.getString();
			} while (!DAO.taxes.stateCheck(state));

			View.request.products();
			String product;
			do
			{
				product = UserIO.inputs.getString();
			} while (!DAO.products.proCheck(product));

			View.request.insert("Area");
			BigDecimal area = UserIO.inputs.getBD(new BigDecimal("100.00"));

			BigDecimal taxRate = DAO.taxes.TR(state);
			BigDecimal CPSF = DAO.products.getC(product);
			BigDecimal LCPSF = DAO.products.getL(product);

			BigDecimal materialCost = Service.calc.costCalc(area, CPSF);
			BigDecimal laborCost = Service.calc.costCalc(area, LCPSF);
			BigDecimal Tax = Service.calc.Tax(materialCost, laborCost, taxRate);
			BigDecimal Total = Service.calc.Total(materialCost, laborCost, Tax);

			DAO.orders.addIt(orderNum, cusName, state, taxRate, product, area, CPSF, LCPSF, materialCost, laborCost, Tax, Total);
			View.display.notify(orderNum, "added");
		}

        public static void remove()
        {
			LocalDate orderDate = UserIO.inputs.getLD(false);
			Model.saveNload.load(orderDate);

			if (DAO.orders.hasNothing())
			{
				View.display.reveal(orderDate, false);
			}
			else
			{
				View.request.insert("Order Number");
				int target = UserIO.inputs.getInt(1, DAO.orders.numOrders());
				View.display.target(target);

				View.request.requestD();
				if (UserIO.inputs.YN())
				{
					DAO.orders.remove(target);
					View.display.notify(target, "deleted");
				}
			}
		}

        public static void edit()
        {
			LocalDate orderDate = UserIO.inputs.getLD(true);
			Model.saveNload.load(orderDate);

			if (DAO.orders.hasNothing())
			{
				View.display.reveal(orderDate, false);
			}
			else
			{
				View.request.insert("Order Number");
				int target = UserIO.inputs.getInt(1, DAO.orders.numOrders());
				View.display.target(target);

				View.request.requestE();
				int change = UserIO.inputs.getInt(1, 4);
				switch (change)
				{
					case 1:
						View.request.insert("Customer Name");
						String cusName = UserIO.inputs.getString();
						DAO.orders.newName(target, cusName);
						break;
					case 2:
						View.request.insert("State Name (Use full name)");
						String state;
						do
						{
							state = UserIO.inputs.getString();
						} while (!DAO.taxes.stateCheck(state));
						DAO.orders.newState(target, state);
						break;
					case 3:
						View.request.products();
						String product;
						do
						{
							product = UserIO.inputs.getString();
						} while (!DAO.products.proCheck(product));
						DAO.orders.newPro(target, product);
						break;
					case 4:
						View.request.insert("Area");
						BigDecimal area = UserIO.inputs.getBD(new BigDecimal("100.00"));
						DAO.orders.newArea(target, area);
						break;
				}
				View.display.notify(target, "edited");
			}
		}
    }
}
