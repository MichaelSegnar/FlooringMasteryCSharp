﻿using java.math;
using NodaTime;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlooringMastery.View
{
    class display
    {
		public static void reveal(LocalDate date, bool exsist)
		{
			String result;
			if (exsist) { result = "Here are the"; } else { result = "There are no"; }

			Console.WriteLine($"{result} orders made on {date}");

			if (exsist) { Console.WriteLine("OrderNumber,CustomerName,State,TaxRate,ProductType,Area,CostPerSquareFoot,LaborCostPerSquareFoot,MaterialCost,LaborCost,Tax,Total\n--------------------"); }
		}

		public static void showOrder(int o, DAO.orders.data info)
		{
			Console.WriteLine($"{o},{info.getCN()},{info.getS()},{info.getTR()},{info.getPT()},{info.getA()},{info.getCPSF()},{info.getLCPSF()},{info.getMC()},{info.getLC()},{info.getTx()},{info.getTl()}");
		}

		public static void proLine(String pro, BigDecimal CPSF, BigDecimal LCPSF)
        {
			Console.WriteLine($"{pro}/{CPSF}/{LCPSF}");
        }

		public static void notify(int order, String effect)
        {
			Console.WriteLine($"Order #{order} has been {effect}.");
		}

		public static void target(int order)
        {
			Console.WriteLine("Here is your order:");
			DAO.orders.getOrder(order);
		}
	}
}
