﻿using NodaTime;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlooringMastery.View
{
    class invalids
    {
		public static void not(String input, String request)
		{
			Console.WriteLine($"{input} is not a valid {request}.\nPlease try again.");
		}

		public static void rangeError(String input)
		{
			Console.WriteLine($"{input} is not within acceptable range.\nPlease try again.");
		}

		public static void notDate(String date)
		{
			Console.WriteLine($"{date} is not a valid date.");
		}

		public static void future(LocalDate now)
		{
			Console.WriteLine($"Invalid date. Inserted date must be after {now}");
		}

		public static void undecided()
		{
			Console.WriteLine("Not a valid response. Please type 'yes' or 'no'.");
		}
	}
}
