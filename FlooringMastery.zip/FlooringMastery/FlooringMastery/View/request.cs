﻿using Lucene.Net.Support;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlooringMastery.View
{
    class request
    {
        public static void menu()
        {
            Console.WriteLine("<Flooring Mastery>\n");
            Console.WriteLine("Select an option:");
            Console.WriteLine("1. Display Order\n2. Add Order\n3. Edit Order\n4. Remove Order\n5. Quit");
        }

        public static void insert(String require)
        {
            Console.WriteLine($"Please type in the {require}:");
        }

        public static void products()
        {
            Console.WriteLine("Please select a product to use:");

            Console.WriteLine("Product/CostPerSquareFoot/LaborCostPerSquareFoot\n----------");
            DAO.products.listPros();
        }

        public static void requestD()
        {
            Console.WriteLine("Would you like to delete it? (yes/no)");
        }

        public static void requestE()
        {
            Console.WriteLine("What would you like to change?\n1. Customer Name\n2. State\n3. Product Type\n4. Area");
        }

    }
}
