﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlooringMastery.Model
{
    public class loadEx
    {
        public static void download()
        {
            String PRODUCTS = "Products.txt";
            String TAXES = "Taxes.txt";

            String product = File.ReadAllText(PRODUCTS);
            String tax = File.ReadAllText(TAXES);

            DAO.products.getProducts(product);
            DAO.taxes.getTax(tax);
        }
    }
}
