﻿using Lucene.Net.Support;
using NodaTime;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlooringMastery.Model
{
    public class saveNload
    {
		static String TEXT = "Orders/Orders_";
		static String DESC = "OrderNumber,CustomerName,State,TaxRate,ProductType,Area,CostPerSquareFoot,LaborCostPerSquareFoot,MaterialCost,LaborCost,Tax,Total";
		static String order = "Orders/Orders_06022013.txt";//default

		public static void load(LocalDate date)
        {
			DAO.orders.clearList();
			String month = date.Month.ToString(), day = date.Day.ToString(), year = date.Year.ToString();

			if (day.Length < 2) { day = "0" + day; }
			if (month.Length < 2) { month = "0" + month; }
			while (year.Length < 4) { year = "0" + year; }
			
			String format = month + day + year;
			order = TEXT + format + ".txt";
		
			if(!File.Exists(order))
            {
				File.WriteAllText(order, DESC);
			}

			DAO.orders.retrieve(order);
		}

		public static void save()
        {
			String record = DESC+"\n";
			HashMap<int, DAO.orders.data> callback = DAO.orders.getData();
			int index = 0, end = callback.Count();

            foreach(KeyValuePair<int, DAO.orders.data> d in callback)
            {
				String line = $"{d.Key},{d.Value.getCN()},{d.Value.getS()},{d.Value.getTR()},{d.Value.getPT()},{d.Value.getA()},{d.Value.getCPSF()},{d.Value.getLCPSF()},{d.Value.getMC()},{d.Value.getLC()},{d.Value.getTx()},{d.Value.getTl()}";
				record = record + line;
				if(index < end) { record = record + "\n"; index++; }
            }

			File.WriteAllText(order, record);
		}
	}
}
