﻿using java.math;
using Lucene.Net.Support;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlooringMastery.DAO
{
    class taxes
    {
        public static HashMap<String, taxData> txs = new HashMap<String, taxData>();

        public class taxData
        {
            private String state;
            private BigDecimal rate;

            public taxData(String a, BigDecimal b)
            {
                this.state = a;
                this.rate = b;
            }

            public String getState() { return state; }
            public BigDecimal getRate() { return rate; }
        }

        public static void getTax(string file)
        {
            String[] lines = file.Split(new String[] { Environment.NewLine }, StringSplitOptions.None);

            //first line is description so it is skipped
            for (int i = 1; i < lines.Length; i++)
            {
                String[] line = lines[i].Split(new String[] { "," }, StringSplitOptions.None);
                txs.Add(line[0], new taxData(line[1], new BigDecimal(line[2])));
            }
        }

        public static bool stateCheck(String state)
        {
            foreach (String s in txs.Keys)
            {
                if (s.Equals(state))
                {
                    return true;
                }
            }

            View.invalids.not(state, "State");
            return false;
        }

        public static BigDecimal TR(String state)
        {
            return txs[state].getRate();
        }
    }
}
