﻿using java.math;
using Lucene.Net.Support;
using NodaTime;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlooringMastery.DAO
{
    public class orders
    {
		public static HashMap<int, data> orderList = new HashMap<int, data>();

		public class data
		{
			private String CustomerName, State;
			private BigDecimal TaxRate;
			private String ProductType;
			private BigDecimal Area, CPSF, LCPSF, MaterialCost, LaborCost, Tax, Total;

			public data(String c, String s, BigDecimal t, String p, BigDecimal a, BigDecimal cf, BigDecimal l, BigDecimal m, BigDecimal lc, BigDecimal tx, BigDecimal to)
			{
				this.CustomerName = c;
				this.State = s;
				this.TaxRate = t;
				this.ProductType = p;
				this.Area = a;
				this.CPSF = cf;
				this.LCPSF = l;
				this.MaterialCost = m;
				this.LaborCost = lc;
				this.Tax = tx;
				this.Total = to;
			}

			public String getCN() { return CustomerName; }
			public String getS() { return State; }
			public BigDecimal getTR() { return TaxRate; }
			public String getPT() { return ProductType; }
			public BigDecimal getA() { return Area; }
			public BigDecimal getCPSF() { return CPSF; }
			public BigDecimal getLCPSF() { return LCPSF; }
			public BigDecimal getLC() { return LaborCost; }
			public BigDecimal getMC() { return MaterialCost; }
			public BigDecimal getTx() { return Tax; }
			public BigDecimal getTl() { return Total; }

			public void setName(String name)
            {
				this.CustomerName = name;
            }

			public void setState(String name, BigDecimal rate)
			{
				this.State = name;
				this.TaxRate = rate;
				reCalc();
			}

			public void setPro(String name, BigDecimal c, BigDecimal l)
			{
				this.ProductType = name;
				this.CPSF = c;
				this.LCPSF = l;
				reCost();
			}

			public void setArea(BigDecimal a)
            {
				this.Area = a;
				reCost();
            }

			public void reCalc()
            {
				this.Tax = Service.calc.Tax(getMC(), getLC(), getTR());
				this.Total = Service.calc.Total(getMC(), getLC(), getTx());
            }

			public void reCost()
            {
				this.MaterialCost = Service.calc.costCalc(getA(), getCPSF());
				this.LaborCost = Service.calc.costCalc(getA(), getLCPSF());
				reCalc();
			}
		}

		public static void clearList()
		{
			orderList.Clear();
		}

		public static void retrieve(String o)
        {
			String[] lines = File.ReadAllLines(o);

			for(int i=1; i<lines.Length; i++)
            {
				String[] toAdd = lines[i].Split(',');
				orderList.Add(Int32.Parse(toAdd[0]),new data(toAdd[1],toAdd[2],new BigDecimal(toAdd[3]),toAdd[4], new BigDecimal(toAdd[5]), new BigDecimal(toAdd[6]), new BigDecimal(toAdd[7]), new BigDecimal(toAdd[8]), new BigDecimal(toAdd[9]), new BigDecimal(toAdd[10]), new BigDecimal(toAdd[11])));
            }
        }

		public static void display(LocalDate date)
        {
			if (orderList.Count() == 0)
			{
				View.display.reveal(date, false);
			}
			else
			{
				View.display.reveal(date, true);
				foreach (KeyValuePair<int, data> o in orderList)
				{
					View.display.showOrder(o.Key, o.Value);
				}
			}
		}

		public static HashMap<int, data> getData()
        {
			return orderList;
        }

		public static int numOrders()
        {
			return orderList.Count();
        }

		public static void addIt(int o, String c, String s, BigDecimal t, String p, BigDecimal a, BigDecimal cf, BigDecimal l, BigDecimal m, BigDecimal lc, BigDecimal tx, BigDecimal to)
        {
			orderList.Add(o, new data(c, s, t, p, a, cf, l, m, lc, tx, to));
		}

		public static bool hasNothing()
        {
			return orderList.Count() == 0;
        }

		public static void getOrder(int order)
        {
			View.display.showOrder(order, orderList[order]);
        }

		public static void remove(int target)
        {
			orderList.Remove(target);
			orderList = reorder(orderList);
		}

		public static HashMap<int, data> reorder(HashMap<int, data> before)
		{
			int pointer = 1;
			HashMap<int, data> after = new HashMap<int, data>();

			foreach (int o in before.Keys)
			{
				after.Add(pointer, before[o]);
				pointer++;
			}

			return after;
		}

		public static void newName(int target, String newName)
        {
			orderList[target].setName(newName);
        }

		public static void newState(int target, String state)
		{
			BigDecimal newRate = DAO.taxes.TR(state);
			orderList[target].setState(state, newRate);
		}

		public static void newPro(int target, String pro)
		{
			BigDecimal newC = DAO.products.getC(pro);
			BigDecimal newL = DAO.products.getL(pro);
			orderList[target].setPro(pro, newC, newL);
		}

		public static void newArea(int target, BigDecimal area)
		{
			orderList[target].setArea(area);
		}
	}
}
