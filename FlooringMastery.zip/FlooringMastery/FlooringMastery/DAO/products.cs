﻿using java.math;
using Lucene.Net.Support;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlooringMastery.DAO
{
    class products
    {
		public static HashMap<String, proData> pros = new HashMap<String, proData>();

		public class proData
		{
            private BigDecimal CPSF;
            private BigDecimal LCPSF;

            public proData(BigDecimal a, BigDecimal b)
            {
                this.CPSF = a;
                this.LCPSF = b;
            }

			public BigDecimal getCPSF() { return CPSF; }
			public BigDecimal getLCPSF() { return LCPSF; }
		}

		public static void getProducts(string file)
        {
			String [] lines = file.Split(new String[] { Environment.NewLine }, StringSplitOptions.None);
			
			//first line is description so it is skipped
			for(int i = 1; i < lines.Length; i++)
			{
				String[] line = lines[i].Split(new String[] { "," }, StringSplitOptions.None);
				pros.Add(line[0], new proData(new BigDecimal(line[1]), new BigDecimal(line[2])));
			}
		}

		public static void listPros()
        {
			foreach(KeyValuePair<String,proData> p in pros)
            {
				View.display.proLine(p.Key,p.Value.getCPSF(),p.Value.getLCPSF());
            }
        }

		public static bool proCheck(String pro)
        {
			foreach (String p in pros.Keys)
			{
				if (p.Equals(pro))
				{
					return true;
				}
			}

			View.invalids.not(pro, "Product");
			return false;
		}

		public static BigDecimal getC(String pro)
        {
			return pros[pro].getCPSF();
        }

		public static BigDecimal getL(String pro)
		{
			return pros[pro].getLCPSF();
		}
	}
}
